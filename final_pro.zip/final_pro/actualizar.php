<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE);
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$estado="ACEPTADA";


$mysqli = new mysqli("localhost", "root", "", "registros");

if($op =="1")
{
    editar($estado);
}



function editar($estado, $mysqli)
{
    $query="UPDATE solicitudes SET estado=$estado WHERE id=$id";
    if($mysqli->query($query))
    {
        $respuesta="OK";
    }
    else
    {
        $respuesta="ERROR";
    }
    echo json_encode($respuesta);
}