
<!DOCTYPE html>
<html>
<head>
<title>REGISTRO DE ALUMNOS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<link href="css/estilo_reg.css" rel="stylesheet" type="text/css" media="all" />
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
</head>
<body>
	
	<div class="main-w3layouts wrapper">
		<h1>REGISTRO DE ALUMNOS</h1>
		<div class="main-agileinfo">
			<div class="agileits-top">
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-users"></i></span>
                                    </div>
                                    <input required type="text" class="form-control" placeholder="Apellidos" id="apellidos" name="apellidos">
                                </div>
                            </div>
                            
				<form action="#" method="post">
					<input class="text" type="text" name="nombre_ap" placeholder="NOMBRE Y APELLIDOS" required="">
                                        <input class="text" type="text" name="carrera" placeholder="CARRERA" required="">
                                        <input class="text" type="text" name="semestre" placeholder="SEMESTRE" required="">
                                        <input class="text" type="text" name="nombre_ap" placeholder="MATRICULA" required="">
					<input class="text email" type="email" name="correoo" placeholder="CORREO ELECTRONICO" required="">
					<input class="text" type="password" name="contraa" placeholder="CONTRASENA" required="">
					
					
					<input type="submit" value="REGISTRARME">
				</form>
				
			</div>
		</div>
		
</body>
</html>