<?php

   
    
//var_dump($_POST);
$mdocente= $_POST["mdocente"];
$nalumno= $_POST["nalumno"];
$apealumno= $_POST["apealumno"];
$semestre= $_POST["semestre"];
$licenciatura= $_POST["licenciatura"];
$tema= $_POST["tema"];
$fecha= $_POST["fecha"];
$estado= "PENDIENTE";

$mysqli = new mysqli("localhost", "root", "", "registros");


if ($mysqli->connect_errno)
    {
    echo "Fall� la conexi�n: ". $mysqli->connect_error;
    exit();
    }


if ($mysqli->query("INSERT INTO solicitudes VALUES (null,'$mdocente','$nalumno','$apealumno','$semestre','$licenciatura','$tema','$fecha','$estado')"))
    { 
     
 
    
    }
    else{
      echo "error: ". $mysqli->connect_error;  
    }
      
    
    
    ?>
        

<META HTTP-EQUIV="REFRESH" CONTENT="3;URL=http://localhost/final_pro/solicitar_as.php">
