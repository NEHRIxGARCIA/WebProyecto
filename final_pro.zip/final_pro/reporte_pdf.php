<?php
include_once 'fpdf/fpdf.php';
$pdf = new FPDF('P','mm','letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Image('imagenes/docentee.png',80,10,60,60,"png");
$pdf->Ln(1);
$pdf->SetFont('Arial','B',10);
$pdf->SetX(10);
$pdf->SetY(80);//posiciona mas a la derecha del texto
$pdf->Cell(75,10,'DOCENTES REGISTRADOS');
$pdf->Cell(10,20,utf8_decode('Fecha: '. date("d-m-Y")));

$pdf->Ln(20);


$pdf->Cell(30,5,'NOMBRE',1,0,'C');
$pdf->Cell(40,5,'APELLIDOS',1,0,'C');
$pdf->Cell(35,5,'AREA',1,0,'C');
$pdf->Cell(25,5,'COMPLEJO',1,0,'C');
$pdf->Cell(25,5,'MATRICULA',1,0,'C');
$pdf->Ln();
$mysqli = new mysqli("localhost", "root", "", "registros");
$query="SELECT * FROM docentes";
$respuesta = array();
if ($result = $mysqli->query($query))
{
    while($row = $result->fetch_array(MYSQLI_ASSOC))
    {
            $respuesta[] = $row;
    }
}
$i=1;
foreach ($respuesta as $value){
    $pdf->SetFont('Arial','',10);
    
    
    $pdf->Cell(30,5,utf8_decode($value["nombre"]),1,0,'C');
    $pdf->Cell(40,5,$value["apellidos"],1,0,'C');
    $pdf->Cell(35,5,$value["area"],1,0,'C');
    $pdf->SetFont('Arial','',8);
    $pdf->Cell(25,5,utf8_decode($value["complejo"]),1,0,'C');
    $pdf->Cell(25,5,utf8_decode($value["matricula"]),1,0,'C');
    
    $pdf->Ln();
    $i++;
}
$pdf->SetY(245);
$pdf->SetFont('Arial','I',8);
$pdf->Cell(0,10,'Page '.$pdf->PageNo().'/{nb}',0,0,'C');
$pdf->Output();

