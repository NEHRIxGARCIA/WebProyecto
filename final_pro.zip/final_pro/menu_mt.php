

<html>
    <head>
        <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
        
       
                 
         
    </head>
    
<body background="imagenes/b33.jpg">
   
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        
        <a class="navbar-brand" href="www.uvp.mx">
          <img src="imagenes/uvp3.png" width="300" height="70" alt="UVP">
        </a>
        <a class="navbar-brand">PORTAL DOCENTES</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
              <a class="nav-link" href="menu_al.php">Inicio <span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="ver_solicitudes.php">Solicitudes<span class="sr-only"></span></a>
            </li>
             <li class="nav-item active">
                 <a class="nav-link" href="aceptar_as.php">Aceptar solicitudes <span class="sr-only"></span></a>
            </li>
             
        
          
            
          </ul>
             <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php"><span class="glyphicon glyphicon-log-in"></span> Cerrar Sesion</a></li>
      </ul>

        </div>
    </nav>
    
    <div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
      
    </div>
    <div class="col-sm-8 text-left"> 
      <h1>BIENVENIDO A HOOLI </h1>
      <p>Hooli es una plataforma pensada para poder agendar asesorias en las cuales, el alumno tenga deficiencia en cuanto a los conocimientos
          adquiridos; Con hooli se prentende agilizar el proceso de solicitar una asesoria, ya que el solicitarla como comunmente se realizaba,
      era un poco dificil, debido a que los docentes y los alumnos tenian diferentes horarios, por lo cual no se lograba concretar dicha asesoria. 
      </p>
      <p>Con hooli tienes la opcion de aceptar solicitud de asesorias que los alumnos envian.</p>
      
       <img width="850" height="450" align="center" src="imagenes/est2.jpg" >
      <hr>
      <h3>Importancia de las asesorias</h3>
      <p>Mediante la asesoria academica se brinda apoyo a los estudiantes para que puedan mejorar la comprension de los diferentes temas de estudio, que conforman el contenido de las asignaturas que cursan en un ciclo escolar.

Tambien se le considera como una actividad dirigida al area del conocimiento que, fundamentalmente, consiste en consultas que un profesor brinda fuera de su tiempo de docencia, sobre temas especificos de su dominio que conforman los contenidos curriculares, con el fin de mejorar la comprension de los temas expuestos en la clase.</p>
    </div>
    <div class="col-sm-2 sidenav">
        
      <div class="well">
          <a title="GMAIL" href="https://www.gmail.com"><img width="40" height="40" align="center" src="imagenes/gmail.png" ></a> 
      </div>
      <div class="well">
          <a title="FACEBOOK" href="https://www.facebook.com"><img width="40" height="40" align="center" src="imagenes/face.png" ></a> 
      </div>
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>UNIVERSIDAD DEL VALLE DE PUEBLA</p>
</footer>
        <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
         <script src="sweetalert/sweetalert2.min.js"></script>
        
</body>

</html>