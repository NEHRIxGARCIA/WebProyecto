<html>
    <head>
          <link rel="icon" type="imagenes/png" href="imagenes/iconos/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
        <link rel="stylesheet" href="sweetalert/sweetalert2.min.css">
        
        
       
                 
         
    </head>
    
<body background="imagenes/b33.jpg">
   
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        
        <a class="navbar-brand" href="www.uvp.mx">
          <img src="imagenes/uvp3.png" width="300" height="70" alt="UVP">
        </a>
        <a class="navbar-brand">PORTAL ALUMNOS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
              <a class="nav-link" href="menu_al.php">Inicio <span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="ver_docentes.php">Ver Docentes <span class="sr-only"></span></a>
            </li>
             <li class="nav-item active">
                 <a class="nav-link" href="solicitar_as.php">Solicitar asesoria <span class="sr-only"></span></a>
            </li>
             <li class="nav-item active">
                 <a class="nav-link" href="estatus_asesoria.php">Estatus de asesorias <span class="sr-only"></span></a>
            </li>
        
          
            
          </ul>
             <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php"><span class="glyphicon glyphicon-log-in"></span> Cerrar Sesion</a></li>
      </ul>

        </div>
    </nav>

    <div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
      
    </div>
    <div class="col-sm-8 text-left"> 
        <hr>
         
    
              <form action="enviar_solicitud.php" method="post"> 
              
          <div class="row">
              
              <div class="col-md-1"></div>
              <div class="col-md-10">
                  <div class="card">
                    <div class="card-header">Solicitar asesoria</div>
                    <div class="card-body">
                        
                        
                            
                        <div class="row">
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1"><i class="fa fa-user"></i></span>
                                    </div>
                                    <input required type="text" class="form-control" placeholder="Matricula Docente " id="mdocente" name="mdocente">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-users"></i></span>
                                    </div>
                                    <input required type="text" class="form-control" placeholder="Nombre alumno" id="nalumno" name="nalumno">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-users"></i></span>
                                    </div>
                                    <input required type="text" class="form-control" placeholder="Apellidos" id="apealumno" name="apealumno">
                                </div>
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1"><i class="fa fa-user"></i></span>
                                    </div>
                                    <input required type="number" class="form-control" placeholder="Semestre" id="semestre" name="semestre">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-users"></i></span>
                                    </div>
                                    <input required type="text" class="form-control" placeholder="Licenciatura" id="licenciatura" name="licenciatura">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-users"></i></span>
                                    </div>
                                    <input required type="text" class="form-control" placeholder="Tema de asesoria" id="tema" name="tema">
                                </div>
                            </div>
                            
                        </div>
                        
                         <div class="row">
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1"><i class="fa fa-user"></i></span>
                                    </div>
                                    <input required type="datetime-local" class="form-control" placeholder="Fecha" id="fecha" name="fecha">
                                </div>
                            </div>
                            
                            
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" id="btnGuardar" class="btn btn-success" onclick="enviar();">Enviar solicitud</button>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
          
          </div>
              
          </form>
          <hr>
    </div>
    <div class="col-sm-2 sidenav">
        
      <div class="well">
          <a title="GMAIL" href="https://www.gmail.com"><img width="40" height="40" align="center" src="imagenes/gmail.png" ></a> 
      </div>
      <div class="well">
          <a title="FACEBOOK" href="https://www.facebook.com"><img width="40" height="40" align="center" src="imagenes/face.png" ></a> 
      </div>
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>UNIVERSIDAD DEL VALLE DE PUEBLA</p>
</footer>
       <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="vendor/select2/select2.min.js"></script>
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
        <script src="sweetalert/sweetalert2.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        
         <script type="text/javascript">
             
             function enviar(){
        
                var mdocente=$("#mdocente").val();
                var nalumno=$("#nalumno").val();
                var apealumno=$("#apealumno").val();
                var semestre=$("#semestre").val();
                var licenciatura=$("#licenciatura").val();
                var tema=$("#tema").val();
                var fecha=$("#fecha").val();
                     
                if(mdocente.trim() === "")
                {
                    $("#mdocente").focus();
                    show_mensaje("Ingresar Matricula del docente","error");
                }
                else if(nalumno.trim() === "")
                {
                     $("#nalumno").focus();
                    show_mensaje("Ingresa tu nombre","error");
                }
                else if(apealumno.trim() === "")
                {
                     $("#apealumno").focus();
                    show_mensaje("Ingresa tus apellidos","error");
                }
                else if(semestre.trim() === "")
                {
                     $("#semestre").focus();
                    show_mensaje("Ingresa semestre","error");
                }
                else if(licenciatura.trim() === "")
                {
                     $("#licenciatura").focus();
                    show_mensaje("Ingresa tu licenciatura","error");
                }
                else if(tema.trim() === "")
                {
                     $("#tema").focus();
                    show_mensaje("Ingresa tema de la asesoria","error");
                }
                else if(fecha === "")
                {
                     $("#fecha").focus();
                    show_mensaje("Ingresa fecha de la asesoria","error");
                }
                else{
                    show_mensaje("Solicitud enviada","success");
                }
                
          }
          
          function show_mensaje(mensaje,icono)
                {
                        Swal.fire({
                            icon: icono,
                            title: mensaje,
                            showClass: {
                                popup: 'animated fadeInDown faster'
                            },
                            hideClass: {
                                popup: 'animated fadeOutUp faster'
                            }
                        });
                 } 
          
             
         </script>
</body>

</html>