<?php

$id= $_POST["id"];
$estado=$_POST["estado"];




$mysqli = new mysqli("localhost", "root", "", "registros");





    $query="UPDATE solicitudes SET estado='$estado' WHERE id=$id";
    if($mysqli->query($query))
    {
        $respuesta="OK";
        
    }
    else
    {
        $respuesta="ERROR";
    }
    echo json_encode($respuesta);


        
    ?>
    