  <?php
$db = "localhost";
$user = "root";
$pass = "";
$dbname = "registros";

$connect = mysqli_connect($db, $user, $pass, $dbname);
$query = "SELECT * FROM docentes";
$result = mysqli_query($connect, $query); 
  ?>


<html>
    <head>
        <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
   <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="css/estilo_tabla.css" rel="stylesheet" type="text/css" media="all" />
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link rel="stylesheet" type="text/css" href="animate/animate.css">
  <link rel="stylesheet" href="sweetalert/sweetalert2.min.css">
       
                 
         
    </head>
    
<body background="imagenes/b33.jpg">
   
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        
        <a class="navbar-brand">
          <img src="imagenes/uvp3.png" width="250" height="45" alt="UVP">
        </a>
        <a class="navbar-brand">PORTAL ALUMNOS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
              <a class="nav-link" href="menu_al.php">Inicio <span class="sr-only"></span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="ver_docentes.php">Ver Docentes <span class="sr-only"></span></a>
            </li>
             <li class="nav-item active">
                 <a class="nav-link" href="solicitar_as.php">Solicitar asesoria <span class="sr-only"></span></a>
            </li>
             <li class="nav-item active">
                 <a class="nav-link" href="estatus_asesoria.php">Estatus de asesorias <span class="sr-only"></span></a>
            </li>
        
          
            
          </ul>
             <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php"><span class="glyphicon glyphicon-log-in"></span> Cerrar Sesion</a></li>
      </ul>

        </div>
         
    </nav>
    
  <div class="container-fluid text-center">      
   <div class="container">
         
    <h3>DOCENTES REGISTRADOS</h3>
    <hr>
     <div class="row">
        <div class="panel panel-primary filterable">
            <div class="panel-heading">
                <h3 class="panel-title"> DOCENTES</h3>
               <button class="btn btn-danger btn-block" onclick="generarPdf();"><i class="fa fa-file-pdf">EXPORTAR DATOS A PDF</i></button>
            </div>
            <table class="table">
                <thead>
                    <tr class="filters">
                          
                        
                        <th><i class="fa fa-user"></i><input type="text" class="form-control" placeholder="NOMBRE" disabled></th>
                        <th><i class="fa fa-user"></i><input type="text" class="form-control" placeholder="APELLIDOS" disabled></th>
                         <th><i class="fa fa-info"></i><input type="text" class="form-control" placeholder="AREA DE ESPECIALIDAD" disabled></th>
                         <th><i class="fa fa-info"></i><input type="text" class="form-control" placeholder="COMPLEJO" disabled></th>
                        <th><i class="fa fa-address-book"></i><input type="text" class="form-control" placeholder="MATRICULA" disabled></th>
                                 
                        
              

                        
                    </tr>
                </thead>
                <tbody>
                    <?php while($row1 = mysqli_fetch_array($result)):;?>
            <tr>
            
                <td><?php echo $row1[1];?></td>
                <td><?php echo $row1[2];?></td>
                <td><?php echo $row1[3];?></td>
                <td><?php echo $row1[4];?></td>
                <td><?php echo $row1[5];?></td>
            </tr>
            <?php endwhile;?>
            </table>
        </div>
    </div>
    <hr>
   
 </div>
    
       </div>
     

<footer class="container-fluid text-center">
  <p>UNIVERSIDAD DEL VALLE DE PUEBLA</p>
</footer>
        <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
         <script src="sweetalert/sweetalert2.min.js"></script>
         
          <script type="text/javascript">
                     function show_mensaje(mensaje,icono)
   { 
        Swal.fire({
            icon: icono,
            title: mensaje,
            showClass: {
                popup: 'animated fadeInDown faster'
            },
            hideClass: {
                popup: 'animated fadeOutUp faster'
            }
        });
        }
        
    
        function generarPdf()
          {
              show_mensaje("PDF CREADO CORRECTAMENTE","success");
              window.open("reporte_pdf.php");
              
            
              
              
          }
          

       </script>
         
        
</body>

</html>

 