-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-06-2020 a las 01:55:01
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `registros`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `licenciatura` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `semestre` int(11) NOT NULL,
  `matricula` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `contra` varchar(30) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`id`, `nombre`, `apellidos`, `licenciatura`, `semestre`, `matricula`, `correo`, `contra`) VALUES
(39, 'HECTOR DAVID', 'MELLADO SOLIS', 'ING EN SISTEMAS', 2, 'TI41851', 'melladosolisd@gmail.com', 'perros23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docentes`
--

CREATE TABLE `docentes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `area` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `complejo` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `matricula` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `contra` varchar(30) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `docentes`
--

INSERT INTO `docentes` (`id`, `nombre`, `apellidos`, `area`, `complejo`, `matricula`, `correo`, `contra`) VALUES
(2, 'EDUARDO ', 'BERRA VILLASENOR', 'TECNOLOGIA', 'KUKULCAN', 'TI48512', 'berra@gmail.com', 'gatos12'),
(3, 'DANIEL', 'CRUZ', 'TECNOLOGIA', 'CALMECAC', 'AR1212', 'daniel@gmail.com', 'perros15'),
(4, 'LAURA', 'MARTINEZ DIAZ', 'SALUD', 'CALMECAC', 'TR87451', 'diana@gmail.com', 'azul45'),
(5, 'DENISE', 'TRUJILLO SANCHEZ', 'SOCIALES', 'KUKULCAN', 'RS54875', 'denise@gmail.com', 'rojo78'),
(6, 'JUAN', 'PEREZ OCAMPO', 'MECATRONICA', 'CALMECAC', 'TY84752', 'juan@gmail.com', 'verde45'),
(7, 'RAUL', 'SANCHEZ GUTIERREZ', 'ADMINISTRACION', 'CALMECAC', 'RF42587', 'raul@gmail.com', 'camello12'),
(8, 'JOSE', 'SALAZAR DIAZ', 'FISIOTERAPIA', 'KUKULCAN', 'SD41578', 'jose@gmail.com', 'gatos34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `id` int(11) NOT NULL,
  `mdocente` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `nalumno` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `apealumno` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `semestre` int(11) NOT NULL,
  `licenciatura` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `tema` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL,
  `estado` varchar(20) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`id`, `mdocente`, `nalumno`, `apealumno`, `semestre`, `licenciatura`, `tema`, `fecha`, `estado`) VALUES
(4, 'TI48512', 'HECTOR DAVID', 'MELLADO SOLIS', 2, 'ING EN SISTEMAS', 'PROGRAMACION', '2020-06-17 15:00:00', 'ACPETADA'),
(6, 'AR1212', 'CARLOS', 'OCAMPO ROSETE', 3, 'ING EN SISTEMAS', 'HTML Y SQL', '2020-06-22 16:42:00', 'ACPETADA'),
(7, 'RF42587', 'PEDRO', 'MENDOZA JIMENEZ', 2, 'LIC EN FISIOTERAPIA', 'HUESOS XD', '2020-06-19 18:53:00', 'PENDIENTE');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `docentes`
--
ALTER TABLE `docentes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de la tabla `docentes`
--
ALTER TABLE `docentes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
